//
//  YFWelcomeVC.swift
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/30.
//  Copyright © 2017年 YF. All rights reserved.
//

import UIKit
import SnapKit
import KBCycleScrollView


let kYFWelcomeCellIdentifier = "kNewFeatureCellIdentifier"
class YFWelcomeVC: UIViewController {

    var btnClicked: (()->Void)?
    
    let imagesArray = ["ws_launch_image1", "ws_launch_image2", "ws_launch_image3"]
    
    var pageControl: UIPageControl!
    
    var collectionView: UICollectionView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.automaticallyAdjustsScrollViewInsets = false
        
        let cycle = KBCycleScrollView(frame: CGRect.zero)
        cycle.count = imagesArray.count
        cycle.delegate = self
        cycle.autoScroll = false
        cycle.autoScrollTimeInterval = CGFloat(imagesArray.count)
        cycle.scrollDirection = .horizontal
        cycle.itemSize = CGSize(width: mScreenWidth, height: mScreenHeight)
        cycle.registerCellClass(YFWelcomeCell.self, identifier: kYFWelcomeCellIdentifier)
        cycle.backgroundColor = .clear
        view.addSubview(cycle)
        
        pageControl = UIPageControl()
        pageControl.numberOfPages = imagesArray.count
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = UIColor(hex: "b0b0b0")
        pageControl.currentPageIndicatorTintColor = UIColor.white
        view.addSubview(pageControl)
        
        let registerBtn = UIButton(type: .custom)
        registerBtn.backgroundColor = UIColor(hex: "#f25625")
        registerBtn.layer.cornerRadius = 4
        registerBtn.layer.masksToBounds = true
        registerBtn.titleLabel?.font = kAppFont(fontName: .semibold, fontSize: 15)
        registerBtn.setTitle("注册", for: .normal)
        registerBtn.addTarget(self, action: #selector(registerBtnClickedHandle), for: .touchUpInside)
        view.addSubview(registerBtn)
        
        let loginBtn = UIButton(type: .custom)
        loginBtn.backgroundColor = UIColor(hex: "#119cbc")
        loginBtn.layer.cornerRadius = 4
        loginBtn.layer.masksToBounds = true
        loginBtn.titleLabel?.font = kAppFont(fontName: .semibold, fontSize: 15)
        loginBtn.setTitle("进入", for: .normal)
        loginBtn.addTarget(self, action: #selector(loginBtnClickedHandle), for: .touchUpInside)
        view.addSubview(loginBtn)
        
       loginBtn.isHidden = true
        registerBtn.isHidden = true
        pageControl.isHidden = true
        
        cycle.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        pageControl.snp.makeConstraints { make in
            make.centerX.equalTo(view)
            make.bottom.equalToSuperview().offset(-25)
            
        }
        
        registerBtn.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(25)
            make.bottom.equalToSuperview().offset(-25)
            make.height.equalTo(44)
            make.width.equalToSuperview().dividedBy(2).offset(-40)
        }
        
        loginBtn.snp.makeConstraints { (make) in
            make.centerX.equalTo(view)
           // make.right.equalToSuperview().offset(-25)
            make.bottom.equalTo(view).offset(-110)
            make.height.equalTo(44)
            make.width.equalToSuperview().dividedBy(2).offset(-40)
        }
        
    }
    
    @objc func registerBtnClickedHandle() {
     //注册
    }
    
    @objc func loginBtnClickedHandle() {
      //登录
    }

}

extension YFWelcomeVC:KBCycleScrollViewDataSource {
    func cycleScrollView(_ cycleScrollView: KBCycleScrollView, index: Int, collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: kYFWelcomeCellIdentifier, for: indexPath) as! YFWelcomeCell
        cell.btnClicked = btnClicked
        cell.imageView?.image = UIImage(named: imagesArray[index])
        cell.enterBtn?.isHidden = !(indexPath.item == imagesArray.count - 1)
        return cell
        
    }
    
}


extension YFWelcomeVC: KBCycleScrollViewDelegate {
    
    func cycleScrollView(_ cycleScrollView: KBCycleScrollView, didScrollTo index: Int) {
        pageControl.currentPage = index
    }
    
    func cycleScrollView(_ cycleScrollView: KBCycleScrollView, didSelectItemAt index: Int) {
        if index == 2 {
            btnClicked!()
        }
    }
    
}

class YFWelcomeCell: UICollectionViewCell {
    
    var btnClicked: (()->Void)?
    
    var imageView: UIImageView?
    
    var enterBtn: UIButton?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        imageView = UIImageView()
        contentView.addSubview(imageView!)
        
        enterBtn = UIButton(type: .custom)
        enterBtn?.setBackgroundImage(UIImage(named: "ws_launch_image_btn"), for: .normal)
        enterBtn?.addTarget(self, action: #selector(enterBtnClick), for: .touchUpInside)
        contentView.addSubview(enterBtn!)
        
        imageView?.snp.makeConstraints { make in
            make.edges.equalTo(contentView)
        }
        
        enterBtn?.snp.makeConstraints({ make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-217 * m6Scale)
            make.size.equalTo(CGSize(width: 216/2, height: 76/2))
        })
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func enterBtnClick() {
        if let btnClicked = btnClicked {
            btnClicked()
        }
    }
}

