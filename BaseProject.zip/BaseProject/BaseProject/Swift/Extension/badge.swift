//
//  badge.swift
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/16.
//  Copyright © 2017年 ESH. All rights reserved.
//

import Foundation

let  TabbarItemNums = 4.0
extension UITabBar {

    func showBadgeOnItemIndex(index:Int) {
    let badgeView = UIView()
     badgeView.tag = 1000 + index
     badgeView.layer.cornerRadius = 5
     badgeView.backgroundColor = UIColor.red
        let width = self.frame.size.width
        let height = self.frame.size.height
        let percentx:CGFloat  = CGFloat((Double(index) + 0.6) / TabbarItemNums)
    let x = ceilf(Float(percentx * width))
      let y = ceilf(Float(0.1 * height))
        badgeView.frame = CGRect(x: CGFloat(x), y: CGFloat(y), width:10.0, height: 10.0)
        self.addSubview(badgeView)
        
        
        
        
    }
    
    func hideBadgeOnItemIndex(index:Int) {
        for view in self.subviews {
            if view.tag == 1000 + index {
            view.removeFromSuperview()
            }
        }
    }
    
   
    

}
