//
//  ViewControllerExtension.swift
//  WolfStreet_iOS
//
//  Created by liyang on 2017/1/12.
//  Copyright © 2017年 Wolf Street. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    
    func emptyBarItem() -> UIBarButtonItem {
        return UIBarButtonItem(customView: UIView())
    }
    
    func quitBarItem() -> UIBarButtonItem {
        return UIBarButtonItem(image: UIImage(named: ""), style: .plain, target: self, action: #selector(quitBarItemClicked))
    }
    
    func backWhiteBarItem() -> UIBarButtonItem {
        return UIBarButtonItem(image: UIImage(named: "head_nav_back")?.withRenderingMode(UIImageRenderingMode.alwaysOriginal), style: .plain, target: self, action: #selector(quitBarItemClicked))
    }

    
    @objc private func quitBarItemClicked() {
        if navigationController != nil {
            self.view.endEditing(true)
            _ = navigationController?.popViewController(animated: true)
        }
    }
    
}
