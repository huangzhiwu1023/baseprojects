//
//  ESToolAPI.swift
//  ESH_OA
//
//  Created by 黄志武 on 2017/9/27.
//  Copyright © 2017年 ESH. All rights reserved.
//

import UIKit
class ESToolAPI: NSObject {
    static let BtnAPI = ESToolAPI()

    func setBtns(arr:[UIButton],tagBase:Int) {
        for i in 0 ..< arr.count {
            let btn = arr[i]
            btn.tag = i + tagBase
            btn.setImage(UIImage.init(named: "select"), for: .selected)
            btn.setImage(UIImage.init(named: "deselect"), for: .normal)
//            btn.tapHandle{  () -> String? in
//                for mbtn in arr {
//                    mbtn.isSelected = mbtn.tag == btn.tag ? true : false
//                }
//               return ""
//            }
        }
    }
    
    func selectBtnTag(arr:[UIButton],tagBase:Int) -> Int{
        for i in 0 ..< arr.count {
            let btn = arr[i]
            if btn.isSelected == true {
                return btn.tag - tagBase
            }
        }
        return -1
    }
    
    //归档
    func mSERIALIZE_ARCHIVE(__objToBeArchived__:NSObject, __filePath__:String)
    {
        NSKeyedArchiver.archiveRootObject(__objToBeArchived__, toFile:__filePath__)
        //
        //    let data = NSMutableData.init();
        //    let archiver = NSKeyedArchiver.init(forWritingWith: data)
        //    archiver.encode(__objToBeArchived__, forKey: __key__)
        //    archiver.finishEncoding()
        //    data.write(toFile: __filePath__, atomically: true)
    }
    
    //解档
    func mSERIALIZE_UNARCHIVE(__filePath__:String)-> Any?{
        
        if NSKeyedUnarchiver.unarchiveObject(withFile:__filePath__) != nil {
            
            return NSKeyedUnarchiver.unarchiveObject(withFile: __filePath__)
        }
        else {
            return nil
        }
        
    }


}
