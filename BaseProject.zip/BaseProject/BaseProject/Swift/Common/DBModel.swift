//
//  DBModel.swift
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/18.
//  Copyright © 2017年 YF. All rights reserved.
//

import UIKit
import FMDB

class DBModel: NSObject {
    
    /**
     1:Documents：应用中用户数据可以放在这里，iTunes备份和恢复的时候会包括此目录
     2:tmp：存放临时文件，iTunes不会备份和恢复此目录，此目录下文件可能会在应用退出后删除
     3:Library/Caches：存放缓存文件，iTunes不会备份此目录，此目录下文件不会在应用退出删除
     */
  static func shareDatabases()->FMDatabase {
       //获取源文件的路径
        let localPath = Bundle.main.path(forResource: "sqlite", ofType: "bundle")
        let path = localPath ?? "" + "sqlite.db"
        //沙河路径
        let dbpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first ?? "" + "sqlite.db"
        //管理
    let fileManager = FileManager.default
    
    let exist = fileManager.fileExists(atPath:dbpath)
    
    if exist == false {
        try! fileManager.copyItem(atPath: path, toPath: dbpath)
    }
    let feedlogDb = FMDatabase(path: dbpath)

  
        return feedlogDb
    }
    
}

class kindModel:DBModel {
    func kinds() {
        let sql = "select * from T_KIND order by d_num"
        let db = DBModel.shareDatabases()
        db.open()
        let rs = try! db.executeQuery(sql, values: nil)
        let str =  rs.string(forColumn: "D_KIND")
        print("\(str)====")
    }
    
}
