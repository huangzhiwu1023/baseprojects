//
//  YFShareViewCell.swift
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/23.
//  Copyright © 2017年 YF. All rights reserved.
//

import UIKit

class YFShareViewCell:UICollectionViewCell {

    lazy var  title = UILabel()
    lazy var image = UIImageView()
   
    
    override init(frame:CGRect){
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func layoutSubviews() {
        setupUI()
    }
}

extension YFShareViewCell {
    fileprivate func setupUI() {
        //title.text = "微信"
        title.font = UIFont.systemFont(ofSize: 15)
        title.textColor = UIColor(hex:"333333")
        contentView.addSubview(title)
        contentView.addSubview(image)
        //
        image.snp.updateConstraints { (make) in
            make.top.equalTo(self.contentView).offset(0)
            make.centerX.equalTo(self.contentView).offset(0)
            make.height.equalTo(35)
            make.width.equalTo(35)
        }
        title.snp.updateConstraints { (make) in
            make.top.equalTo(self.image.snp.bottom).offset(25)
            make.centerX.equalTo(self.contentView).offset(0)
        }
        
    }
    
}
