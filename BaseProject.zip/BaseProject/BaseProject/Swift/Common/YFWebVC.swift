//
//  YFWebVC.swift
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/19.
//  Copyright © 2017年 YF. All rights reserved.
//

import UIKit
import WebKit
import SnapKit

/**
 例子：
 YFWebVC * vcc = [[YFWebVC alloc] init];
 vcc.urlString = @"https://www.baidu.com";
*/

class YFWebVC: UIViewController {

    var urlString :String?
    var type = ""
    var web : WKWebView?
    var webH : CGFloat = 0.0
    var webW : CGFloat = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
       createWebView()
       configItem()
        getWebHight()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    deinit {
        self.web?.scrollView.removeObserver(self, forKeyPath: "contenSize", context: nil)
        NotificationCenter.default.removeObserver(self)
        
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        if let obj = object as? UIScrollView {
            if (obj == web?.scrollView) && (keyPath ==  "contenSize") {
                let scrollView = web?.scrollView
                print("New contentSize: %f x %f", scrollView?.contentSize.width ?? 0.0, scrollView?.contentSize.height ?? 0.0);
                webH = (scrollView?.contentSize.height) ?? 0.0
                webW = (scrollView?.contentSize.width) ?? 0.0
            }
        }
        
      
        
       
    }
}

extension YFWebVC {
    //加载H5
    fileprivate func createWebView() {
        let webView = WKWebView()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.configuration.userContentController.add(self, name: "postCode")//添加H5消息监听
        view.addSubview(webView)
        self.web = webView
        webView.snp.makeConstraints { make in
            make.edges.equalTo(view)
        }
         // webView.loadHTMLString(urlString!, baseURL: nil)
        if let urlString = urlString {
            if let url = URL(string: urlString) {
                webView.load(URLRequest(url: url))
            }
        }
    }

   //导航功能显示
    func configItem() {
        let leftItem = UIBarButtonItem(image: UIImage(named: "head_nav_back"), style: .plain, target: self, action: #selector(leftItemClicked))
        navigationItem.leftBarButtonItem = leftItem
    }
    
    //如果H5不是第一页，则执行H5的返回
    @objc func leftItemClicked() {
        if (self.web?.canGoBack)! {
            _ = self.web?.goBack()
        }else {
            _ = self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    //获取H5高度
    func getWebHight() {
        //H5内容添加监听
        self.web?.scrollView.addObserver(self, forKeyPath: "contenSize", options: .new, context: nil)
    }
}



//设置web的标题就是原生的标题
extension YFWebVC :WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard let _ = title else {
            title = webView.title
            return
        }
    }
    
}

//H5获取的数据
extension YFWebVC : WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "消息名字(postCode)" {
            print(message.body)
            if let dic = message.body as? [String : String] {
                print(dic)
                //比如用户点击某个按钮功能，发消息及把需要的数据id发发送给我接受
                
            }
        }
    }
    
}


extension YFWebVC :WKUIDelegate {
     //HTML页面Alert出内容,H需要提示显示提示框，接受的这个消息及选择情况在返回给H5
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let ac = UIAlertController(title: webView.title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        ac.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.cancel, handler: { (a) -> Void in
            completionHandler()
        }))
        
        self.present(ac, animated: true, completion: nil)
    }
    
    //Html 页面弹出confirm时调用此方法
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let ac = UIAlertController(title: webView.title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        ac.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler:
            { (ac) -> Void in
                completionHandler(true)  //按确定的时候传true
        }))
        ac.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler:
            { (ac) -> Void in
                completionHandler(false)  //取消传false
        }))
        
        self.present(ac, animated: true, completion: nil)
    }
}


