//
//  ESNetworkKaven.swift
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/14.
//  Copyright © 2017年 ESH. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import Alamofire
import RxAlamofire
import SwiftyJSON

extension ESNetwork {

    //获取底部权限
    func getBottomPermissions(userId:String,rightTypeId:Int,command:String) -> Observable<[String: Any]>  {
        
        let url = String(format:"/woyuan/right/SystemManager2/ashx/API.ashx?command=%@s&rightTypeId=%d&userId=%@",command,rightTypeId,userId)
        return get(url)
    }
    
///MARK:=====================================资讯模块=============================================

    func getNewsList(columnName:String,page:Int,size:Int)->Observable<[String:Any]> {
        
        let urlStr = "/cms/article/findOnlineArticle"
        let parm = [ "columnName":columnName,
        "page":page,
        "rows":size
            ] as? [String : Any]
        
        return post(urlStr, parm)
    }
    

}
