//
//  RxResult.swift
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/14.
//  Copyright © 2017年 ESH. All rights reserved.
//

import UIKit
import RxSwift
import Alamofire
import ObjectMapper

public extension ObservableType {
    public func mapResult() -> Observable<Alamofire.Result<E>> {
        return flatMap { Observable.just( Alamofire.Result.success($0)) }
            .catchError { Observable.just( Alamofire.Result.failure($0)) }
    }
}
