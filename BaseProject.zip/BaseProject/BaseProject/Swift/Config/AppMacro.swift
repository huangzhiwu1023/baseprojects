//
//  AppMacro.swift
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/13.
//  Copyright © 2017年 ESH. All rights reserved.
//

import UIKit

// MARK:- 沙盒路径
let mDocumentDir    = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first
let mCacheDir       = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true).first
let mTmpDir         = NSTemporaryDirectory()

// MARK:- 设备系统相关
let mAppVersion     = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as! String

// MARK:- 页面设计相关
let mNavBarHeight   = CGFloat(44.0)
let mTabBarHeight   = CGFloat(49.0)
let mScreenBounds   = UIScreen.main.bounds
let mScreenWidth    = UIScreen.main.bounds.width
let mScreenHeight   = UIScreen.main.bounds.height

let mStatusBarHeight    = UIApplication.shared.statusBarFrame.size.height
let mNavHeight          = mNavBarHeight + mStatusBarHeight

let IS_IPHONE_X  = mScreenHeight == 812 ? true : false
let navH = IS_IPHONE_X ? 88 : 64




//系统色
//let  mAppMainColor = UIColor(hex:"#3071b3")
let mAppLightColor = UIColor(red: 185/255.0, green: 180/255.0, blue: 176/255.0, alpha: 1)
//185 180 176
/// MARK:- 按屏幕缩放比例
let m5Scale             = (mScreenWidth/640.0)
let m6Scale             = (mScreenWidth/750.0)
let m6PScale            = (mScreenWidth/1242.0)






