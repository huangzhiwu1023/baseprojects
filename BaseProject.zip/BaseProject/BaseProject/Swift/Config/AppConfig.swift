//
//  AppConfig.swift
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/13.
//  Copyright © 2017年 ESH. All rights reserved.
//

import UIKit
import SwiftDate
import RxSwift
import RxCocoa
import Alamofire
import RxAlamofire
import Hue

//MARK: appID
public let kAppID = ""
let kAppUrl = "https://itunes.apple.com/cn/app/"

//MARK:网络请求主站点
#if DEBUG
    //测试环境
 let N_HostSiteMain = "http://59.110.160.88:8101" //"http://192.168.0.44:8888"//其他接口
 let N_HostSiteEquipment = "http://101.200.86.224:8088"//设备类接口
#else
    //真实环境
let N_HostSiteMain = "http://101.200.86.224:1111"
let N_HostSiteEquipment = "http://101.200.86.224:8088"
    
#endif

//MARK:占位图
let kPlaceholderImage = UIImage(named: "ws_launch_image1")

//MARK:第三方平台信息key

let kShareSDKAppKey         = ""

/// 极光推送
let kJPushKey               = "1d8cdda99b2d846316c4c5aa"






//mark 用户信息保存key
let USERKEY = "userInfo"
let kUserPermissions = "kUserPermissions"
let kSellerIDs = "kSellerIDs"
//MARK: 程序字体
enum kAppFontNameType: String{
    case regular    = "PingFangSC-Regular"
    case semibold   = "PingFangSC-Semibold"
    case ultralight = "PingFangSC-Ultralight"
    case thin       = "PingFangSC-Thin"
    case light      = "PingFangSC-Light"
    case medium     = "PingFangSC-Medium"
}

/// 快速创建PingFangSC字体，兼容iOS9以下系统
///
/// - Parameters:
///   - fontName: 字体名称 kAppFontNameType
///   - fontSize: 字号
/// - Returns: UIFont类型
func kAppFont(fontName: kAppFontNameType = .regular, fontSize: CGFloat = 17) -> UIFont {
    if let appFont = UIFont(name: fontName.rawValue, size: fontSize) {
        return appFont
    } else {
        switch fontName {
        case .regular:
            return UIFont.systemFont(ofSize: fontSize)
        case .semibold:
            return UIFont.boldSystemFont(ofSize: fontSize)
        case .ultralight:
            return UIFont.italicSystemFont(ofSize: fontSize)
        default:
            return UIFont.systemFont(ofSize: fontSize)
        }
    }
    
}

/// 时间格式转换
///
/// - Parameter custom: 时间的字符串格式，默认是"yyyy-MM-dd HH:mm:ss"
/// - Returns: 转换后的
//func messageTimeFormar(str:String ,_ custom: String = "yyyy-MM-dd HH:mm:ss") -> String {
//    let originalDate = DateInRegion(string: str, format: .custom(custom))?.absoluteDate
//    if let originalDate = originalDate {
//        if originalDate.isToday {
//            return originalDate.string(custom: "HH:mm")
//        } else if originalDate.isYesterday {
//            return "昨天"
//        } else {
//            return originalDate.string(custom: "yyyy-MM-dd")
//        }
//    } else {
//        return str
//    }
//}


func autoLabelSize(with text:String , labelWidth: CGFloat ,attributes : [NSAttributedStringKey : Any]) -> CGFloat{
    var size = CGRect()
    let size2 = CGSize(width: labelWidth, height: 0)//设置label的最大宽度
    size = text.boundingRect(with: size2, options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: attributes , context: nil);
    return size.size.height
}

//归档
func mSERIALIZE_ARCHIVE(__objToBeArchived__:NSObject, __filePath__:String)
{
    NSKeyedArchiver.archiveRootObject(__objToBeArchived__, toFile:__filePath__)
    //
    //    let data = NSMutableData.init();
    //    let archiver = NSKeyedArchiver.init(forWritingWith: data)
    //    archiver.encode(__objToBeArchived__, forKey: __key__)
    //    archiver.finishEncoding()
    //    data.write(toFile: __filePath__, atomically: true)
}

//解档
func mSERIALIZE_UNARCHIVE(__filePath__:String)-> Any?{
    
    if NSKeyedUnarchiver.unarchiveObject(withFile:__filePath__) != nil {
        
        return NSKeyedUnarchiver.unarchiveObject(withFile: __filePath__)
    }
    else {
        return nil
    }
    
}
