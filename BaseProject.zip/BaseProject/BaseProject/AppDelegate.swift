//
//  AppDelegate.swift
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/16.
//  Copyright © 2017年 YF. All rights reserved.
//

import UIKit
import SwiftyImage
import Hue
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate{
    func tabBarController(_ tabBarController: UITabBarController!, didSelect control: UIControl!) {
        
    }
    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame:UIScreen.main.bounds)
        if let rootWindow = window {
            rootWindow.backgroundColor = UIColor.white
            rootWindow.makeKeyAndVisible()
        }
        
        configGlobalStyle()
        confignJpush(launchOptions)
        let vc = YFRootVC()
        
        
        let key = "CFBundleShortVersionString"
        let version = Bundle.main.infoDictionary![key]  ?? ""
        let saveVersion: String = UserDefaults.standard.object(forKey: key) as? String ?? ""
        
        if saveVersion.count == 0 {
            //引导 + 广告
            UserDefaults.standard.set(version, forKey: key)
            UserDefaults.standard.synchronize()
            window?.rootViewController = vc
            
//            let wvc = YFWelcomeVC()
//            window?.rootViewController = wvc
//            wvc.btnClicked = {[weak self] in
//                self?.window?.rootViewController = vc
//                //self?.addADView()
////                self?.getADImage()
//            }
            
        }else {
          //广告
            window?.rootViewController = vc
           // self .addADView()
//            self .getADImage()
        }
        
        
   
        return true
    }
    
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        JPUSHService.registerDeviceToken(deviceToken)
    }
    
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        JPUSHService.handleRemoteNotification(userInfo)
        
        handlePushContent(userInfo: userInfo)
        
        completionHandler(.newData)
    }
    
    
    //获取数据库数据=====
    //   let arr : [KindsModel] = KindsModel.kinds() as! [KindsModel]
    //   let m = arr[0]
    //    print("=s数据=\(m.kind)")
    //==================
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

//
extension AppDelegate {
    
    
}

extension AppDelegate {
    //配置导航
    func configGlobalStyle() {
        //title、背景
        let navTitleDic = [NSAttributedStringKey.foregroundColor: UIColor.black,
                           NSAttributedStringKey.font: UIFont.boldSystemFont(ofSize: 18)]
        let navBar = UINavigationBar.appearance()
        navBar.titleTextAttributes = navTitleDic
        navBar.barTintColor = UIColor.brown
        navBar.tintColor = UIColor.orange
        
        navBar.backIndicatorImage = UIImage(named: "head_nav_back")?.withRenderingMode(.alwaysOriginal)
        navBar.backIndicatorTransitionMaskImage = UIImage(named: "head_nav_back")?.withRenderingMode(.alwaysOriginal)
        navBar.setBackgroundImage(UIImage.resizable().color(.white).image, for: .default)
        let barItemTitleDic = [NSAttributedStringKey.foregroundColor: UIColor.clear,
                               NSAttributedStringKey.font: UIFont.boldSystemFont(ofSize: 18)]
        let barItem = UIBarButtonItem.appearance()
        
        barItem.setTitleTextAttributes(barItemTitleDic, for: .normal)
        let tabBar = UITabBar.appearance()
        tabBar.backgroundImage = UIImage.resizable().color(.white).image
        tabBar.tintColor = UIColor.black
        URLSessionConfiguration.default.timeoutIntervalForRequest = 30
        UIApplication.shared.applicationIconBadgeNumber = 0
        //JPUSHService.setBadge(0)
    }
    
    
//    func addADView() -> Void {
//        let adView = YFFullScreenAdView()
//        adView.tag = 100
//        adView.duration = 5
//        adView.waitTime = 3
//        adView.adImageTapBlock = {(t:String?)in
//            print("t=\(String(describing: t))");
//        }
//        window?.addSubview(adView)
//    }
    
//    func getADImage() -> Void {
//        let adView:YFFullScreenAdView = window?.viewWithTag(100) as! YFFullScreenAdView
//        let additionalTime: DispatchTimeInterval = .seconds(2)
//        DispatchQueue.main.asyncAfter(deadline: .now() + additionalTime, execute: {
//            let urlSting :String  = "http://s8.mogucdn.com/p2/170223/28n_4eb3la6b6b0h78c23d2kf65dj1a92_750x1334.jpg"
//            adView.reloadAdImage(withUrl: urlSting, withProvice: "")
//        })
//    }
    
    
    func showForceUpdateAlert() {
        
        let vc = UIApplication.shared.keyWindow?.rootViewController
        if let presentVC = vc?.presentedViewController {
            presentVC.dismiss(animated: false, completion: nil)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let confirmAction = UIAlertAction(title: "确定", style: .default, handler: { (alertAction) in
                if let url = URL(string: kAppUrl) {
                    UIApplication.shared.openURL(url)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        exit(0)
                    }
                }
            })
            let alert = UIAlertController(title: "提示", message: "当前版本已不再受支持，请前往App Store更新到最新版本", preferredStyle: .alert)
            alert.addAction(confirmAction)
            UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
            if let url = URL(string: kAppUrl) {
                UIApplication.shared.openURL(url)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    exit(0)
                }
            }
        }
        
    }
    
    
}




// MARK: - JPUSHRegisterDelegate, 极光推送处理

extension AppDelegate: JPUSHRegisterDelegate{
    @available(iOS 10.0, *)
    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, openSettingsFor notification: UNNotification?) {
        
    }
    
    /// 配置Jpush
    /// - Parameter launchOptions: 启动时的信息
    func confignJpush(_ launchOptions: [UIApplicationLaunchOptionsKey: Any]?) {
        
        NotificationCenter.default.addObserver(self, selector: #selector(receiveJPushCustomMessage(_:)), name: NSNotification.Name.jpfNetworkDidReceiveMessage, object: nil)
        
        if #available(iOS 10, *) {
            let entity = JPUSHRegisterEntity()
            entity.types = NSInteger(UNAuthorizationOptions.alert.rawValue) |
                NSInteger(UNAuthorizationOptions.sound.rawValue) |
                NSInteger(UNAuthorizationOptions.badge.rawValue)
            JPUSHService.register(forRemoteNotificationConfig: entity, delegate: self)
        } else if #available(iOS 8, *) {
            // 可以自定义 categories
            JPUSHService.register(
                forRemoteNotificationTypes: UIUserNotificationType.badge.rawValue |
                    UIUserNotificationType.sound.rawValue |
                    UIUserNotificationType.alert.rawValue,
                categories: nil)
        } else {
            // ios 8 以前 categories 必须为nil
            JPUSHService.register(
                forRemoteNotificationTypes: UIRemoteNotificationType.badge.rawValue |
                    UIRemoteNotificationType.sound.rawValue |
                    UIRemoteNotificationType.alert.rawValue,
                categories: nil)
        }
        
        #if DEBUG
            ///测试环境配置
            JPUSHService.setup(withOption: launchOptions, appKey: kJPushKey, channel: "Developer", apsForProduction: false)
        #else
            ///正式环境配置
            JPUSHService.setup(withOption: launchOptions, appKey: kJPushKey, channel: "App Store", apsForProduction: true)
        #endif
    }
    
    //处理自定义消息
    @objc func receiveJPushCustomMessage(_ notification: Notification) {
        print(notification.userInfo ?? "")
        
        
    }
    
    /// 远程通知处理
    ///
    /// - Parameter userInfo: 远程通知信息
    func handlePushContent(userInfo: [AnyHashable : Any]) {
        
        // TODO: 通知处理
        print("收到通知");
    }
    
    @available(iOS 10.0, *)

    
    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, willPresent notification: UNNotification!, withCompletionHandler completionHandler: ((Int) -> Void)!) {
        let userInfo = notification.request.content.userInfo
        if (notification.request.trigger?.isKind(of: UNPushNotificationTrigger.self) ?? false) {
            JPUSHService.handleRemoteNotification(userInfo)
            
            let alertType = "" //userInfo["AlertType"] as? String
            if alertType == "jpush108" {
                // 其他消息

               // NotificationCenter.default.post(name: Notification.Name.App.DidReceiveNewChatMessage, object: nil)
            } else if alertType == "jpush109" {
                // 系统通知
           
                
             //   NotificationCenter.default.post(name: Notification.Name.App.DidReceiveNewChatMessage, object: nil)
            } else if alertType == "jpush112" {
                // type: "join" 加入申请，“accept”， 接受，“refuse”， 拒绝
              
            }
            
            
        } else {
            // 本地通知
        }
        completionHandler(Int(UNNotificationPresentationOptions.alert.rawValue))
    }
    

    
    @available(iOS 10.0, *)
    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, didReceive response: UNNotificationResponse!, withCompletionHandler completionHandler: (() -> Void)!) {
        let userInfo = response.notification.request.content.userInfo
        if (response.notification.request.trigger?.isKind(of: UNPushNotificationTrigger.self) ?? false) {
            JPUSHService.handleRemoteNotification(userInfo)
            
            handlePushContent(userInfo: userInfo)
            
            let alertType = userInfo["AlertType"] as? String
            if alertType == "jpush108" {
             
                
            } else if alertType == "jpush109" {
                // 系统通知
               
            } else if alertType == "jpush112" {
                // type: "join" 加入申请，“accept”， 接受，“refuse”， 拒绝
               
            }
            
        } else {
            // 本地通知
        }
        completionHandler()
    }
    
   
    
}

