//
//  DBModel.m
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/18.
//  Copyright © 2017年 YF. All rights reserved.
//

#import "DBModel.h"

@implementation DBModel
+ (FMDatabase *)sharedDatabase{
    static FMDatabase *database = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *localPath=[[NSBundle mainBundle] pathForResource:@"sqlite" ofType:@"bundle"];
        NSString *path = [localPath stringByAppendingPathComponent:@"sqlite.db"];
        NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        NSString *dbPath = [docPath stringByAppendingPathComponent:@"sqlite.db"];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if (![fileManager fileExistsAtPath:dbPath]) {
            [fileManager copyItemAtPath:path toPath:dbPath error:nil];
            NSLog(@"dbPath: %@", dbPath);
        }
        database = [FMDatabase databaseWithPath:dbPath];
   });
    [database open];
    return database;
}
@end
