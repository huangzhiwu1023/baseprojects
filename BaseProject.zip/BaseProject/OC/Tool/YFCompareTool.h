//
//  YFCompareTool.h
//  jsyf_user
//
//  Created by 吕祥 on 2017/12/14.
//  Copyright © 2017年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YFComparisonModelModel.h"

@interface YFCompareTool : NSObject
/**
 将机型model存入本地,如果目录为空则创建目录,否则添加在数组后面
 */
+ (BOOL)writeInCompareModel:(ComparisonModelSenddata *)model;
//获取本地已经存储的model数组
+ (NSArray *)getLocalCompareModelList;
//删除model且进行重新存储
+ (BOOL)deleteCompareModel:(NSInteger)index;
//清空本地所有数据
+ (BOOL)deleteAllCompareModel;
//查看当前设备是否已经加入本地
+ (BOOL)modelHaveInLocalList:(NSString *)equipmentID;
//查看当前设备机型和已经加入的机型是否一致
+ (BOOL)currentTypeCodeisEqualTo:(NSString *)typeCode;
@end
