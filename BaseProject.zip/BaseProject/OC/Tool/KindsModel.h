//
//  KindsModel.h
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/18.
//  Copyright © 2017年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DBModel.h"
@interface KindsModel : DBModel

@property(nonatomic,strong) NSString *kind;
@property(nonatomic,strong) NSString *introKind;
@property(nonatomic,strong) NSString *introKind2;
@property(nonatomic) NSInteger num;

- (BOOL)removeKind;

+ (NSArray *)kinds;
@end
