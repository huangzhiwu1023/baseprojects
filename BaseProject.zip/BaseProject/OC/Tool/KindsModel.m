//
//  KindsModel.m
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/18.
//  Copyright © 2017年 YF. All rights reserved.
//

#import "KindsModel.h"

@implementation KindsModel
+ (NSArray *)kinds{
    NSMutableArray *dataArr = [NSMutableArray new];
    FMResultSet *result = [[KindsModel sharedDatabase] executeQueryWithFormat:@"select * from T_KIND order by d_num"];
    while ([result next]) {
        KindsModel *model = [self new];
        model.kind = [result stringForColumn:@"D_KIND"];
        model.num = [result longForColumn:@"D_NUM"];
        model.introKind = [result stringForColumn:@"D_INTROKIND"];
        model.introKind2 = [result stringForColumn:@"D_INTROKIND2"];
        [dataArr addObject:model];
    }
    [[KindsModel sharedDatabase] closeOpenResultSets];
    [[self sharedDatabase] close];
    return [dataArr copy];
}

- (BOOL)removeKind{
    return [[KindsModel sharedDatabase] executeUpdateWithFormat:@"delete from T_KIND where d_kind = %@", self.kind] && [[KindsModel sharedDatabase] executeUpdateWithFormat:@"delete from T_SHI where d_kind = %@", self.kind];
}
@end
