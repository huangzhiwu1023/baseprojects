//
//  YFTitleView.h
//  jsyf_user
//
//  Created by 吕祥 on 2018/1/4.
//  Copyright © 2018年 YF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFTitleView : UIView

@end
