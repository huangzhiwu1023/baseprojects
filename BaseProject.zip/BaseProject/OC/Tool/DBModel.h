//
//  DBModel.h
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/18.
//  Copyright © 2017年 YF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FMDB/FMDB.h>
@interface DBModel : NSObject
+ (FMDatabase *)sharedDatabase;
@end
