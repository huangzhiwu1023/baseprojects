//
//  publicMacro.h
//  jsyf_user
//
//  Created by 黄志武 on 2017/10/16.
//  Copyright © 2017年 YF. All rights reserved.
//

#ifndef publicMacro_h
#define publicMacro_h
#pragma mark - 判断当前设备
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define iPhone3                   ([UIScreen mainScreen].bounds.size.height < 480)
#define iPhone4                   ([UIScreen mainScreen].bounds.size.height == 480)
#define iPhone5                   ([UIScreen mainScreen].bounds.size.height == 568)
#define iPhone6                   ([UIScreen mainScreen].bounds.size.height == 667)
#define iPhone6p                  ([UIScreen mainScreen].bounds.size.height == 736)
#define IS_IPHONE_X (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 812.0f)
#define NETWOTK_MANAGER             [YFHttpManager sharedInstance]
//定义屏幕框 高
#define  MAIN_HEIGHT                  [UIScreen mainScreen].bounds.size.height
#define  MAIN_WIDTH                   [UIScreen mainScreen].bounds.size.width
#define  MAIN_FRAME                   [UIScreen mainScreen].bounds
#define  HEIGHT_NAVIGATION             64
#define  HEIGHT_NAVIGATION_X           88

#define  SCREEN_EQUAL_480              (MAIN_HEIGHT == 480 ? YES :NO )
#define  DISTANCE_TOP                  ((OS_ABOVE_IOS7) ? 0 : 20)
#define  DISTANCE_TOP_IOS6             0
#define  CIRCLE_TOP                    ((OS_ABOVE_IOS7) ? 20 :0)
#define  HEIGTH_IS_480                  ((int)MAIN_HEIGHT==480)
#define  HEIGHT_TAB_BOTTOM             49

#define statusBar  IS_IPHONE_X ? 24 : 0
#define NaviHeight (IS_IPHONE_X ? 88 : 64)
#define TABBARHEIGHT IS_IPHONE_X ? 83 : 49
#define BottomHeight IS_IPHONE_X ? 34 : 0

#define mWindow             [[[UIApplication sharedApplication] windows] lastObject]
#define mKeyWindow          [[UIApplication sharedApplication] keyWindow]
#define mDelegateWindow     [[[UIApplication sharedApplication] delegate] window]

#define RANDOM_COLOR [UIColor colorWithHue: (arc4random() % 256 / 256.0) saturation:((arc4random()% 128 / 256.0 ) + 0.5) brightness:(( arc4random() % 128 / 256.0 ) + 0.5) alpha:1]

//单例声明的公用函数
#define SINGLETON_FOR_HEADER(className) \
+ (className *)sharedInstance;

//单例实现的公用函数
#define SINGLETON_FOR_CLASS(className) \
+ (className *)sharedInstance { \
static className *shared = nil; \
static dispatch_once_t onceToken; \
dispatch_once(&onceToken, ^{ \
shared = [[self alloc] init]; \
}); \
return shared; \
}



#ifdef DEBUG
#define SpeLog(format, ...) NSLog(format, ## __VA_ARGS__)
#else
#define SpeLog(format, ...)
#endif

#ifdef DEBUG
#define SpeAssert(e) assert(e)
#else
#define SpeAssert(e)
#endif

//是否为空或是[NSNull null]
#define NotNilAndNull(_ref)  (((_ref) != nil) && (![(_ref) isEqual:[NSNull null]]))
#define IsNilOrNull(_ref)   (((_ref) == nil) || ([(_ref) isEqual:[NSNull null]]))

//字符串是否为空
#define IsStrEmpty(_ref)    (((_ref) == nil) || ([(_ref) isEqual:[NSNull null]]) ||([(_ref)isEqualToString:@""]))
//数组是否为空
#define IsArrEmpty(_ref)    (((_ref) == nil) || ([(_ref) isEqual:[NSNull null]]) ||([(_ref) count] == 0))

//颜色创建
#undef  RGBCOLOR
#define RGBCOLOR(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]

#undef  RGBACOLOR
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#undef    HEX_RGB
#define HEX_RGB(V)        [UIColor colorWithRGBHex:V]

#undef UIColorFromHex
#define UIColorFromHex(s)  [UIColor colorWithRed:(((s & 0xFF0000) >> 16))/255.0green:(((s &0xFF00) >>8))/255.0 blue:((s &0xFF))/255.0 alpha:1.0]

//颜色转换

#define mRGB(r, g, b)     [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]
#define mRGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

//rgb颜色转换（16进制->10进制）
#define mHexColor(hex) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:1.0]



typedef NS_ENUM(NSInteger, STATETYPE)
{
    STATETYPEBROWSE = 0,
    STATETYPECOLLECT,
};
#define equalTo(...)                     mas_equalTo(__VA_ARGS__)
#define mHexColorAlpha(hex,a) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:a]


//================

#define mDocumentDir   [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]
#define mCacheDir      [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject]
#define mTmpDir        NSTemporaryDirectory()
#define mHomeDir       NSHomeDirectory()

#define kAppDelegate ((AppDelegate *)[UIApplication sharedApplication].delegate)
//----------方法简写-------
#define mWindow             [[[UIApplication sharedApplication] windows] lastObject]
#define mKeyWindow          [[UIApplication sharedApplication] keyWindow]
#define mDelegateWindow     [[[UIApplication sharedApplication] delegate] window]
#define mUserDefaults       [NSUserDefaults standardUserDefaults]
#define mNotificationCenter [NSNotificationCenter defaultCenter]
#define mFont(size)         [UIFont systemFontOfSize:size]
#define mB_Font(size)       [UIFont boldSystemFontOfSize:size]
//id对象与NSData之间转换

#define mObjectToData(object)   [NSKeyedArchiver archivedDataWithRootObject:object]
#define mDataToObject(data)     [NSKeyedUnarchiver unarchiveObjectWithData:data]
//度弧度转换

#define mDegreesToRadian(x)      (M_PI * (x) / 180.0)
#define mRadianToDegrees(radian) (radian*180.0) / (M_PI)
//颜色转换

#define mRGB(r, g, b)     [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]
#define mRGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

//系统蓝色
#define mAppMainColor mHexColor(0x3071b3)
#define mAppLightColor  mRGB(185, 180, 176)

//rgb颜色转换（16进制->10进制）
#define mHexColor(hex) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:1.0]

#define mHexColorAlpha(hex,a) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:a]

//G－C－D
#define mGCDBackground(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), block)
#define mGCDMain(block)       dispatch_async(dispatch_get_main_queue(),block)
#define mGCDAfter(sec, block) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)), dispatch_get_main_queue(), block)
#define mTimeSec 5

//简单的以AlertView显示提示信息
#define mAlertView(title, msg) \
UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil \
cancelButtonTitle:@"确定" \
otherButtonTitles:nil]; \
[alertView show];

//简单的以AlertController显示提示信息
#define mAlertController(title, msg, currentVC) \
UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];\
[alertController addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {\
}]];\
[currentVC presentViewController:alertController animated:YES completion:nil];\


//----------设备系统相关---------
#define mIsiP4     ([UIScreen mainScreen].bounds.size.height == 480.0)
#define mIsiP5     ([UIScreen mainScreen].bounds.size.height == 568.0)
#define mIsiP6     ([UIScreen mainScreen].bounds.size.height == 667.0)
#define mIsiP6P    ([UIScreen mainScreen].bounds.size.height == 736.0)
#define mIsiPad     [[UIDevice currentDevice].model containString:@"iPad"]
#define mIsiPhone   (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define mIsiOS8     [[[UIDevice currentDevice] systemVersion] integerValue] == 8
#define mIsiOS7     [[[UIDevice currentDevice] systemVersion] integerValue] == 7
#define mIsiOS6     [[[UIDevice currentDevice] systemVersion] integerValue] == 6

#define iOS7Later ([UIDevice currentDevice].systemVersion.floatValue >= 7.0f)
#define iOS8Later ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f)
#define iOS9Later ([UIDevice currentDevice].systemVersion.floatValue >= 9.0f)
#define iOS9_1Later ([UIDevice currentDevice].systemVersion.floatValue >= 9.1f)

#define mLanguage   [[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"][0]
#define mSystemVersion   ([[UIDevice currentDevice] systemVersion])
#define mCurrentLanguage ([[NSLocale preferredLanguages] objectAtIndex:0])
#define mAPPVersion      [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]
//----------页面设计相关-------
#define mNavBarHeight         44
#define mTabBarHeight         49
#define mScreenBounds         ([UIScreen mainScreen].bounds)
#define mScreenWidth          ([UIScreen mainScreen].bounds.size.width)
#define mScreenHeight         ([UIScreen mainScreen].bounds.size.height)
#define mMaxScreen            (MAX(mScreenWidth, mScreenHeight))//横竖屏切换
#define mMinScreen            (MIN(mScreenWidth, mScreenHeight))

#define mStatusBarHeight      ([UIApplication sharedApplication].statusBarFrame.size.height)
#define mNavHeight            (NaviHeight + mStatusBarHeight)
#define m6PScale              (mScreenWidth/1242.0)
#define m6Scale               (mScreenWidth/750.0)
#define m5Scale               (mScreenWidth/640.0)
#define k6Scale               (mScreenWidth/375.0)


#define USERNAME @"username"
#define PASSWORD @"password"
#define SECRETKEY @"secretkey"

//调试模式下输入NSLog，发布后不再输入。
#ifdef DEBUG
#define NSLog(...) NSLog(@"%s 第%d行 \n %@\n\n",__func__,__LINE__,[NSString stringWithFormat:__VA_ARGS__])
#else
#define NSLog(...) NSLog(@"%s 第%d行 \n %@\n\n",__func__,__LINE__,[NSString stringWithFormat:__VA_ARGS__])
#endif

// block self
#define mWeakSelf  __weak typeof (self)weakSelf = self;
#define mStrongSelf typeof(weakSelf) __strong strongSelf = weakSelf;

/* 封装归档keyedArchiver操作 */
#define mWZLSERIALIZE_ARCHIVE(__objToBeArchived__, __key__, __filePath__)    \
\
NSMutableData *data = [NSMutableData data]; \
NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];   \
[archiver encodeObject:__objToBeArchived__ forKey:__key__];    \
[archiver finishEncoding];  \
[data writeToFile:__filePath__ atomically:YES]


/* 封装反归档keyedUnarchiver操作 */
#define mWZLSERIALIZE_UNARCHIVE(__objToStoreData__, __key__, __filePath__)   \
NSMutableData *dedata = [NSMutableData dataWithContentsOfFile:__filePath__]; \
NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:dedata];  \
__objToStoreData__ = [unarchiver decodeObjectForKey:__key__];  \
[unarchiver finishDecoding]


#define gkeyFromEnvironment @"abcd01234567890123456789"
#define gdqFromEnvironment @"abcd01234567890123456789"

#define UmengKey @"5a3773f6b27b0a11940000ec"

#endif /* publicMacro_h */
