//
//  AppConfig.h
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/14.
//  Copyright © 2017年 ESH. All rights reserved.
//

#import <Foundation/Foundation.h>

//正式环境
 //"http://192.168.0.44:8888"//张伟个人
#ifdef DEBUG
//测试环境主站点
#define N_HostSiteMain    @"http://59.110.160.88:8101"      //主要接口

#else
///正式环境主站点
#define N_HostSiteMain    @"http://47.93.176.227:"      //正式环境

#endif

/*
 开发环境：
 店铺:http://47.94.197.87:36080/jsyf-sys
 cms:http://47.94.197.87:34080/cms
 
 测试环境：
 店铺:http://59.110.160.88:8101/jsyf-sys
 cms:http://59.110.160.88:8101/cms
 
 
 正式环境：
 店铺:http://47.93.176.227:36080/jsyf-sys
 cms:http://47.93.176.227:35080/cms
 */


/// 占位图片
#define kPlaceholderImage     [UIImage imageNamed:@"占位图"]
#define kPlaceholderHeadImage [UIImage imageNamed:@"defaultHeader"]  //评论头像
#define kPlaceHolderCycleImage [UIImage imageNamed:@"占位图"]  //轮播图占位
//详情占位
#define kEquipmentPlaceHolder [UIImage imageNamed:@"机型详情占位.jpg"]
#define kShopPlaceHolder [UIImage imageNamed:@"店铺详情占位.jpg"]

///第三方key


// 苹方斜体
#define kFont_PF_Ultralight(fontSize) [UIFont fontWithName:@"PingFangSC-Ultralight" size:fontSize]
// 苹方常规
#define kFont_PF_Regular(fontSize) [UIFont fontWithName:@"PingFangSC-Regular" size:fontSize]
// 苹方粗体
#define kFont_PF_Semibold(fontSize) [UIFont fontWithName:@"PingFangSC-Semibold" size:fontSize]
#define kFont_PF_Thin(fontSize) [UIFont fontWithName:@"PingFangSC-Thin" size:fontSize]
#define kFont_PF_Light(fontSize) [UIFont fontWithName:@"PingFangSC-Light" size:fontSize]
#define kFont_PF_Medium(fontSize) [UIFont fontWithName:@"PingFangSC-Medium" size:fontSize]


///MARK:APP基本色=========
#define kBottomBgColor    mHexColor(0xF5F5F5) //灰色的底色
#define kLineColor        mHexColor(0xEBEBEB)  //灰色的线
#define kBuleWordColor    mHexColor(0x2196F3)  //蓝色的字
#define kBlackWordColor   mHexColor(0x222222) //黑色的字
#define kDarkWordColor   mHexColor(0x757575)  //深灰色的字
#define kLightWordColor    mHexColor(0xCBCBCB)  //浅灰色的字
#define kYellowColor mHexColor(0xfdc12f)
#define kRedColor mHexColor(0xF44336)
#define kButtonLineColor mHexColor(0xE0E0E0)  //按钮间隔线颜色 eg.设备丨吨位
//mark: app 基本字体大小
#define kFont12 [UIFont systemFontOfSize:12]
#define kFont14 [UIFont systemFontOfSize:14]
#define kFont15 [UIFont systemFontOfSize:15]
#define KFont16 [UIFont systemFontOfSize:16]

#define RandColor RGBColor(arc4random_uniform(255), arc4random_uniform(255), arc4random_uniform(255))
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define HexColorInt32_t(rgbValue) \
[UIColor colorWithRed:((float)((0x##rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((0x##rgbValue & 0x00FF00) >> 8))/255.0 blue:((float)(0x##rgbValue & 0x0000FF))/255.0  alpha:1]

/////////////////////////// 懒加载 /////////////////////////////
#define ELazyMutableArray(_array) \
return !(_array) ? (_array) = [NSMutableArray array] : (_array);


#pragma mark OSS相关key
#define AccessKey @""
#define SecretKey @""
#define endPointOSS @"oss-cn-shanghai.aliyuncs.com"
#define testBucket @""

#pragma mark 用户信息保存key
#define USERKEY @"userInfo"
#define kUserPermissions @"kUserPermissions"//底部权限
#define kSellerIDs @"kSellerIDs"//销售下属ID集合
#define kRequest_error @"网络错误,请稍后重试"

