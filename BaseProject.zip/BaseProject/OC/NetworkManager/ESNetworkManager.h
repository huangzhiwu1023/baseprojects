//
//  ESNetworkManager.h
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/14.
//  Copyright © 2017年 ESH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#ifndef ESNetworkManager_h
#define ESNetworkManager_h

typedef void (^ESNetWordSuccess)(NSURLSessionDataTask * task, id responseObject);

typedef void (^ESNetWordFailure)(NSURLSessionDataTask * task, NSError * error);

typedef void (^ESNetWordResult)(id data, NSError *error);

typedef void (^ESUploadProgress)(float progress);

typedef void (^ESDownloadProgress)(float progress);

#endif

@class RACSignal;
@interface ESNetworkManager : NSObject


+ (NSURLSessionDataTask *)GET:(NSString *)hostString params:(NSDictionary *)params success:(ESNetWordSuccess)success failure:(ESNetWordFailure)failure;

+ (NSURLSessionDataTask *)POST:(NSString *)hostString params:(NSDictionary *)params success:(ESNetWordSuccess)success failure:(ESNetWordFailure)failure;

+ (void)uploadImages:(NSArray *)imageArray
           urlString:(NSString *)urlString
              params:(NSDictionary *)params
         targetWidth:(float)width
        successBlock:(ESNetWordSuccess)successBlock
         failurBlock:(ESNetWordFailure)failureBlock
            progress:(ESUploadProgress)progress;

+ (void)downloadFileWithSavaPath:(NSString *)savePath
                       urlString:(NSString *)urlString
                          result:(ESNetWordResult)resultBlock
                        progress:(ESDownloadProgress)progress;

/**
 *  取消所有的网络请求
 */
+ (void)cancelAllRequest;

/**
 *  取消指定的url请求
 *
 *  @param requestType 该请求的请求类型
 *  @param string      该请求的完整url
 */

+ (void)cancelHttpRequestWithRequestType:(NSString *)requestType requestUrlString:(NSString *)string;

@end

@interface ESNetworkManager (RAC)

/// RAC Post请求
+ (RACSignal *)rac_POST:(NSString *)hostString params:(NSDictionary *)params;

/// RAC Get请求
+ (RACSignal *)rac_GET:(NSString *)hostString params:(NSDictionary *)params;

#pragma ============================================================================================================





#pragma mark- ---------------------------实例--------------------------------
////登录
//+ (RACSignal *)requestWithUserName:(NSString *)username Withpwd:(NSString *)pwd;
////获取权限
//+ (RACSignal *)requestWithUserId:(NSString *)userId;
////获取销售下属ID
//+ (RACSignal *)getSellerIDs:(NSString *)userID;

#pragma mark- ---------------------------新机模块--------------------------------
//获取设备类型接口(挖掘机,装载机), 获取吨位(大中小挖)
+ (RACSignal *)getStoreEquipmentParam:(NSDictionary *)dic;
//获取品牌列表 新机主页
+ (RACSignal *)getBrandListParam:(NSDictionary *)dic;
//所有新机接口
+ (RACSignal *)getAllNewMachineWithParam:(NSDictionary *)dic;
//获取设备品牌接口
+ (RACSignal *)getBrandFilterParam:(NSDictionary *)dic;
//获取设备品牌头部详情
+ (RACSignal *)getBrandHeadDetail:(NSDictionary *)dic;
//所有经销商接口
+ (RACSignal *)getCompanyListData:(NSDictionary *)dic;
//请求店铺头部详情
+ (RACSignal *)getCompanyHeadDetail:(NSDictionary *)dic;
//获取所有省份
+ (RACSignal *)getProvinceList:(NSDictionary *)dic;
//获取所以市
+ (RACSignal *)getCityList:(NSDictionary *)dic;
//请求店铺详情下的新机列表接口
+ (RACSignal *)getCompanyNewMachineList:(NSDictionary *)dic;
//请求店铺下资讯&详情列表接口
+ (RACSignal *)getCompanyNewsList:(NSDictionary *)dic;
//获取机型的同时获取吨位信息
+ (RACSignal *)getStyleAndTonList:(NSDictionary *)dic;
//请求设备详情,商品详情
+ (RACSignal *)getEquipmentHeadDetail:(NSDictionary *)dic;
//请求设备概述
+ (RACSignal *)getEquipmentDesc:(NSDictionary *)dic;
//请求设备参数
+ (RACSignal *)getEquipmentParam:(NSDictionary *)dic;
//请求设备照片
+ (RACSignal *)getEquipmentPhotos:(NSDictionary *)dic;
//请求询价管理
+ (RACSignal *)getAskPrice:(NSDictionary *)dic;
//参数对比获取所有品牌
+ (RACSignal *)getComparisonBrand:(NSDictionary *)dic;
//参数对比获取所以有型号
+ (RACSignal *)getComparisonModel:(NSDictionary *)dic;
//参数对比参数
+ (RACSignal *)getCompareParam:(NSDictionary *)dic;
//获取所有的省市区
+ (RACSignal *)getAllProvinceAndCity:(NSDictionary *)dic;
//询价页面获取经销商
+ (RACSignal *)getPriceShop:(NSDictionary *)dic;
//对店铺,商品发表评论接口
+ (RACSignal *)sendComment:(NSDictionary *)dic;
//请求评论列表
+ (RACSignal *)getCommentList:(NSDictionary *)dic;
//请求文章详情
+ (RACSignal *)getArticleDetail:(NSDictionary *)dic;
//新的新机首页接口(带索引)
+ (RACSignal *)getNewBrandList:(NSDictionary *)dic;

#pragma mark- ---------------------------个人中心模块--------------------------------
//用户密码登陆
+ (RACSignal *)userLoginwithParam:(NSDictionary *)dic;
//获取短信验证码
+ (RACSignal *)getCodeWithParam:(NSDictionary *)dic;
//修改用户头像
+ (RACSignal *)updateCustomImgWithParam:(NSDictionary *)dic;
//图片上传
+ (RACSignal *)uploadingImagWithParam:(NSDictionary *)dic;
//验证手机验证码
+ (RACSignal *)checkPhoneCodeWithParam:(NSDictionary *)dic;
//用户注册
+ (RACSignal *)userregisterWithParam:(NSDictionary *)dic;
//意见反馈
+ (RACSignal *)feedBackWithParam:(NSDictionary *)dic;
//短信登陆
+ (RACSignal *)codeLoginWithParam:(NSDictionary *)dic;
//验证手机号是否注册
+ (RACSignal *)checkPhoneisRegisterWithParam:(NSDictionary *)dic;
//修改昵称
+ (RACSignal *)updateNickNameWithParam:(NSDictionary *)dic;
//忘记密码
+ (RACSignal *)updateCustomerPasswordWithParam:(NSDictionary *)dic;
//密钥登陆
+ (RACSignal *)validateLoginKeyWithParam:(NSDictionary *)dic;
#pragma mark- ---------------------------首页与资讯模块--------------------------------
//获取读秒广告图片
+(RACSignal *)getADImageWithParam:(NSDictionary *)dic;


@end


