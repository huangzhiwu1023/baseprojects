//
//  ESNetworkManager.m
//  ESH_OA
//
//  Created by 黄志武 on 2017/8/14.
//  Copyright © 2017年 ESH. All rights reserved.
//

#import "ESNetworkManager.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import <AFNetworking/AFNetworking.h>
#define kTimeOutInterval 15


@implementation ESNetworkManager
+ (AFHTTPSessionManager *)shareSessionManager
{
    static AFHTTPSessionManager *shareManager = nil;
    static dispatch_once_t onceToken;
    mWeakSelf
    dispatch_once(&onceToken, ^{
        AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc] initWithBaseURL: [NSURL URLWithString:N_HostSiteMain]];
        [manager setSecurityPolicy:[weakSelf customSecurityPolicy]];
      manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"text/html", @"text/plain", @"text/json", @"text/javascript", @"application/json", @"application/xml"]];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.requestSerializer.timeoutInterval = 15;
        shareManager = manager;
    });
    return shareManager;
}

+ (NSURLSessionDataTask *)GET:(NSString *)hostString params:(NSDictionary *)params success:(ESNetWordSuccess)success failure:(ESNetWordFailure)failure
{
    NSString *urlString = [NSString stringWithFormat:@"%@",hostString];
    if ([hostString hasPrefix:@"http"]) {
        
    }else {
#ifdef DEBUG
        //测试环境主站点
  urlString = [NSString stringWithFormat:@"%@%@", N_HostSiteMain, hostString];
#else
        ///正式环境主站点
        if ([hostString hasPrefix:@"/cms"]) {
           urlString = [NSString stringWithFormat:@"%@%@%@", N_HostSiteMain,@"35080", hostString];
        }else {
          urlString = [NSString stringWithFormat:@"%@%@%@", N_HostSiteMain,@"36080", hostString];
        }

#endif
       
    }

    
     AFHTTPSessionManager *manager = [self shareSessionManager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    return [manager GET:urlString
              parameters:params
                progress:nil
                 success:^(NSURLSessionDataTask * task, id responseObject){
                     NSError *jsonError = nil;
                     NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
                     if ([responseDic isKindOfClass:[NSDictionary class]]) {
                             success(task, responseObject);
                     } else {
                         success(task, responseObject);
                     }
                 } failure:failure];
}

+ (NSURLSessionDataTask *)POST:(NSString *)hostString params:(NSDictionary *)params success:(ESNetWordSuccess)success failure:(ESNetWordFailure)failure
{
    NSMutableDictionary *paramsDic = (params?:@{}).mutableCopy;
    NSString *urlString = [NSString stringWithFormat:@"%@",hostString];
    
    if ([hostString hasPrefix:@"http"]) {
    }else {
#ifdef DEBUG
        urlString = [NSString stringWithFormat:@"%@%@", N_HostSiteMain, hostString];

#else
        ///正式环境主站点
        if ([hostString hasPrefix:@"/cms"]) {
            urlString = [NSString stringWithFormat:@"%@%@%@", N_HostSiteMain,@"35080", hostString];
        }else {
            urlString = [NSString stringWithFormat:@"%@%@%@", N_HostSiteMain,@"36080", hostString];
        }

#endif

    }
    AFHTTPSessionManager *manager = [self shareSessionManager];
    //验证token
    return [manager POST:urlString
              parameters:paramsDic
                progress:nil
                 success:^(NSURLSessionDataTask * task, id responseObject){
                     NSError *jsonError = nil;
                     NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
                     if ([responseDic isKindOfClass:[NSDictionary class]]) {
                            //特殊错误码判断
                             success(task, responseObject);
                     } else {
                         success(task, responseObject);
                     }
                 } failure:failure];
}

+ (AFSecurityPolicy*)customSecurityPolicy
{
    // /先导入证书
    NSString *cerPath = [[NSBundle mainBundle] pathForResource:@"avantouch" ofType:@"cer"];//证书的路径
    NSData *certData = [NSData dataWithContentsOfFile:cerPath];
    
    // AFSSLPinningModeCertificate 使用证书验证模式
//    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    AFSecurityPolicy *securityPolicy;
    // allowInvalidCertificates 是否允许无效证书（也就是自建的证书），默认为NO
    // 如果是需要验证自建证书，需要设置为YES
    securityPolicy.allowInvalidCertificates = YES;
    
    //validatesDomainName 是否需要验证域名，默认为YES；
    //假如证书的域名与你请求的域名不一致，需把该项设置为NO；如设成NO的话，即服务器使用其他可信任机构颁发的证书，也可以建立连接，这个非常危险，建议打开。
    //置为NO，主要用于这种情况：客户端请求的是子域名，而证书上的是另外一个域名。因为SSL证书上的域名是独立的，假如证书上注册的域名是www.google.com，那么mail.google.com是无法验证通过的；当然，有钱可以注册通配符的域名*.google.com，但这个还是比较贵的。
    //如置为NO，建议自己添加对应域名的校验逻辑。
    securityPolicy.validatesDomainName = NO;
    
    securityPolicy.pinnedCertificates = [NSSet setWithObjects:certData, nil];
    
    return securityPolicy;
}

#pragma mark - 文件下载

+ (void)downloadFileWithSavaPath:(NSString *)savePath
                       urlString:(NSString *)urlString
                          result:(ESNetWordResult)resultBlock
                        progress:(ESDownloadProgress)progress;
{
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    [manager downloadTaskWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlString]] progress:^(NSProgress * _Nonnull downloadProgress) {
        progress(downloadProgress.completedUnitCount / downloadProgress.totalUnitCount);
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        return  [NSURL URLWithString:savePath];
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        resultBlock(filePath, error);
    }];
}

#pragma mark - 多图上传
+ (void)uploadImages:(NSArray *)imageArray
           urlString:(NSString *)urlString
              params:(NSDictionary *)params
         targetWidth:(float)width
        successBlock:(ESNetWordSuccess)successBlock
         failurBlock:(ESNetWordFailure)failureBlock
            progress:(ESUploadProgress)progress;
{
    //1.创建管理者对象
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"text/html", @"text/plain", @"text/json", @"text/javascript", @"application/json", @"application/xml"]];

    [manager POST:urlString parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSUInteger i = 0 ;
        /**出于性能考虑,将上传图片进行压缩*/
        for (NSData * imageData in imageArray) {
            //拼接data
           [formData appendPartWithFileData:imageData name:@"file" fileName:@"something.jpg" mimeType:@"image/jpeg"];
            i++;
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
      // NSLog(@"%@/%@",uploadProgress.completedUnitCount ,uploadProgress.totalUnitCount);
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary *  _Nullable responseObject) {
        successBlock(task, responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task, error);
    }];

}
#pragma mark - 取消所有的网络请求

+ (void)cancelAllRequest
{
    [[self shareSessionManager].operationQueue cancelAllOperations];
}

#pragma mark - 取消指定的url请求/

+ (void)cancelHttpRequestWithRequestType:(NSString *)requestType requestUrlString:(NSString *)string
{
    NSError * error;
    /**根据请求的类型 以及 请求的url创建一个NSMutableURLRequest---通过该url去匹配请求队列中是否有该url,如果有的话 那么就取消该请求*/
    NSString * urlToPeCanced = [[[[AFHTTPSessionManager manager].requestSerializer requestWithMethod:requestType URLString:string parameters:nil error:&error] URL] path];
    for (NSOperation * operation in [AFHTTPSessionManager manager].operationQueue.operations) {
        //如果是请求队列
        if ([operation isKindOfClass:[NSURLSessionTask class]]) {
            //请求的类型匹配
            BOOL hasMatchRequestType = [requestType isEqualToString:[[(NSURLSessionTask *)operation currentRequest] HTTPMethod]];
            //请求的url匹配
            BOOL hasMatchRequestUrlString = [urlToPeCanced isEqualToString:[[[(NSURLSessionTask *)operation currentRequest] URL] path]];
            //两项都匹配的话  取消该请求
            if (hasMatchRequestType&&hasMatchRequestUrlString) {
                [operation cancel];
            }
        }
    }
}
#pragma mark ---------------RAC-------------------------

+ (RACSignal *)rac_GET:(NSString *)hostString params:(NSDictionary *)params{
    RACSignal *signal = [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
        [self GET:hostString params:params success:^(NSURLSessionDataTask *task, id responseObject) {
            NSError *jsonError = nil;
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
            if ([responseDic isKindOfClass:[NSDictionary class]]) {
                NSString *errorCode = responseDic[@"e"][@"code"];
                if (errorCode.integerValue == 0) {
                    [subscriber sendNext:responseDic];
                    [subscriber sendCompleted];
                } else {
                   [subscriber sendError:[NSError errorWithDomain:responseDic[@"e"][@"desc"] code:0 userInfo:@{NSLocalizedDescriptionKey: responseDic[@"e"][@"desc"]?: @"未知网络错误"}]];
                }
            }else{
                [subscriber sendError:jsonError];
            }
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            [subscriber sendError:error];
        }];
        return [RACDisposable disposableWithBlock:^{
            
        }];
    }];
    return signal;
    
}

+ (RACSignal *)rac_POST:(NSString *)hostString params:(NSDictionary *)params
{
    RACSignal *signal = [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
        [self POST:hostString params:params success:^(NSURLSessionDataTask *task, id responseObject) {
            NSError *jsonError = nil;
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&jsonError];
                if ([responseDic isKindOfClass:[NSDictionary class]]) {
                    NSString *errorCode = responseDic[@"e"][@"code"];
                    if (errorCode.integerValue == 0) {
                        [subscriber sendNext:responseDic];
                        [subscriber sendCompleted];
                    } else {
                        [subscriber sendError:[NSError errorWithDomain:responseDic[@"e"][@"desc"] code:errorCode.integerValue userInfo:@{NSLocalizedDescriptionKey: responseDic[@"e"][@"desc"]?: @"未知网络错误"}]];
                    }
                }else{
                    [subscriber sendError:jsonError];
                }
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
          NSError *newError = [NSError errorWithDomain:error.localizedDescription code:error.code userInfo:@{NSLocalizedDescriptionKey: @"网络错误,请稍后重试"}];
            
            [subscriber sendError:newError];
        }];
        return [RACDisposable disposableWithBlock:^{
            
        }];
    }];
    return signal;
}

#pragma mark- ---------------------------实例-------------------------------



#pragma mark- ---------------------------新机模块--------------------------------
+ (RACSignal *)getStoreEquipmentParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/storeEquipmentParam/findParamListToChild.json" params:dic];
}
+ (RACSignal *)getBrandListParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/home/findBrandListByTypeCode.json" params:dic];
}
+ (RACSignal *)getAllNewMachineWithParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/home/findEquipmentByParam.json" params:dic];
}
+ (RACSignal *)getBrandFilterParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/home/findBrandListByParam.json" params:dic];
}
+ (RACSignal *)getBrandHeadDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/brand/findBrandById.json" params:dic];
}
+ (RACSignal *)getCompanyListData:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/StoreBrandManage/findStoreListByBrandIdAndParam.json" params:dic];
}
+ (RACSignal *)getCompanyHeadDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/StoreBrandManage/findStoreListByBrandIdAndParam.json" params:dic];
}
+ (RACSignal *)getProvinceList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/area/listProvince.json" params:dic];
}
+ (RACSignal *)getCityList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/area/listCityByProCode.json" params:dic];
}
+ (RACSignal *)getCompanyNewMachineList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/shopFrontPage/findShopGoods.json" params:dic];
}
+ (RACSignal *)getCompanyNewsList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/storeInformation/findStoreInformationList.json" params:dic];
}
+ (RACSignal *)getStyleAndTonList:(NSDictionary *)dic {
     return [ESNetworkManager rac_POST:@"/jsyf-sys/home/findTypeCodeWithTonnageCode.json" params:dic];
}
+ (RACSignal *)getEquipmentHeadDetail:(NSDictionary *)dic {
     return [ESNetworkManager rac_POST:@"/jsyf-sys/goodsDetail/productDetail.json" params:dic];
}
+ (RACSignal *)getEquipmentDesc:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/equipmentDetails/getEquipmentIntroductionAndContrastParam.json" params:dic];
}
+ (RACSignal *)getEquipmentParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/equipmentDetails/listEquipmentParam.json" params:dic];
}
+ (RACSignal *)getEquipmentPhotos:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/equipmentDetails/listDetailTabAtlas.json" params:dic];
}
+ (RACSignal *)getAskPrice:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/enquiry/saveEnquiry.json" params:dic];
}
+ (RACSignal *)getComparisonBrand:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/parameterComparison/findAllBrands.json" params:dic];
}
+ (RACSignal *)getComparisonModel:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/parameterComparison/findModelNameByBrandId.json" params:dic];
}
+ (RACSignal *)getCompareParam:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/parameterComparison/compareEquipmentToApp.json" params:dic];
}
+ (RACSignal *)getAllProvinceAndCity:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/area/findAllProviceWithCity.json" params:dic];
}
+ (RACSignal *)getPriceShop:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/enquiry/enquiryDetail.json" params:dic];
}
+ (RACSignal *)sendComment:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/discuss/pushComment.json" params:dic];
}
+ (RACSignal *)getCommentList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/discuss/findDiscussList.json" params:dic];
}
+ (RACSignal *)getArticleDetail:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"/jsyf-sys/storeActivity/getStoreActivityDetailById.json" params:dic];
}
+ (RACSignal *)getNewBrandList:(NSDictionary *)dic {
    return [ESNetworkManager rac_POST:@"http://47.94.197.87:36080/jsyf-sys/home/findBrandListByTypeCodeToApp.json" params:dic];
}

#pragma mark- ---------------------------个人中心模块--------------------------------

+(RACSignal *)userLoginwithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customer/login.json"] params:dic];
}

+(RACSignal *)updateCustomImgWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customerBaseInfo/updateCustomImg.json"] params:dic];
}

+(RACSignal *)getCodeWithParam:(NSDictionary *)dic
{
     return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/securityCode/getPhoneCode.json"] params:dic];
}

+(RACSignal *)uploadingImagWithParam:(NSDictionary *)dic
{
     return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/attachmentFile/multiFileUpload.json"] params:dic];
}

+(RACSignal *)checkPhoneCodeWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/securityCode/judgePhoneCodeAndCodeImage.json"] params:dic];

}

+ (RACSignal *)userregisterWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customer/signUp.json"] params:dic];
}

+ (RACSignal *)feedBackWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customerSuggestion/saveCustomerSuggestion.json"] params:dic];
}

+(RACSignal *)codeLoginWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customer/loginByPhoneCode.json"] params:dic];
}

+(RACSignal *)checkPhoneisRegisterWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customer/validateUserName.json"] params:dic];
}

+ (RACSignal *)updateNickNameWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customerBaseInfo/saveCustomerBaseInfo.json"] params:dic];
}

+(RACSignal *)updateCustomerPasswordWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customer/updateCustomerPassword.json"] params:dic];
}

+(RACSignal *)validateLoginKeyWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/customer/validateLoginKey.json"] params:dic];
}
#pragma mark- ---------------------------首页与资讯模块--------------------------------

+ (RACSignal *)getADImageWithParam:(NSDictionary *)dic
{
    return [ESNetworkManager rac_POST:[NSString stringWithFormat:@"%@",@"/jsyf-sys/adverManage/findAdverManageToApp.json"] params:dic];
}




@end
